import type { VirtualizedListProps } from 'react-native'
import { VirtualizedList as RNVirtualizedList } from 'react-native'
import { copyComponentProperties } from '../utils'
import { generateDataSet } from './generateDataSet'
import { toRNWClassName } from './rnw'

export const VirtualizedList = copyComponentProperties(RNVirtualizedList, (props: VirtualizedListProps) => {
    return (
        <RNVirtualizedList
            {...props}
            style={[toRNWClassName(props.className), props.style]}
            contentContainerStyle={[toRNWClassName(props.contentContainerClassName), props.contentContainerStyle]}
            ListFooterComponentStyle={[toRNWClassName(props.ListFooterComponentClassName), props.ListFooterComponentStyle]}
            ListHeaderComponentStyle={[toRNWClassName(props.ListHeaderComponentClassName), props.ListHeaderComponentStyle]}
            dataSet={generateDataSet(props)}
        />
    )
})

export default VirtualizedList
