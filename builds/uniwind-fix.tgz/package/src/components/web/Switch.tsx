import type { SwitchProps } from 'react-native'
import { Switch as RNSwitch } from 'react-native'
import { copyComponentProperties } from '../utils'
import { generateDataSet } from './generateDataSet'
import { toRNWClassName } from './rnw'
import { useUniwindAccent } from './useUniwindAccent'

export const Switch = copyComponentProperties(RNSwitch, (props: SwitchProps) => {
    const trackColorOn = useUniwindAccent(props.trackColorOnClassName)
    const trackColorOff = useUniwindAccent(props.trackColorOffClassName)
    const thumbColor = useUniwindAccent(props.thumbColorClassName)

    return (
        <RNSwitch
            {...props}
            style={[toRNWClassName(props.className), props.style]}
            thumbColor={props.thumbColor ?? thumbColor}
            trackColor={{ true: props.trackColor?.true ?? trackColorOn, false: props.trackColor?.false ?? trackColorOff }}
            dataSet={generateDataSet(props)}
        />
    )
})

export default Switch
