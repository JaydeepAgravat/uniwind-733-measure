import type { CustomResolutionContext, CustomResolver } from 'metro-resolver'
import { realpathSync } from 'node:fs'
import { basename, dirname, sep } from 'node:path'

type ResolverConfig = {
    platform: string | null
    resolver: CustomResolver
    context: CustomResolutionContext
    moduleName: string
}

let cachedInternalBasePath: string | null = null

export const isInternalOrigin = (originModulePath: string) => {
    if (cachedInternalBasePath === null) {
        try {
            cachedInternalBasePath = dirname(realpathSync(require.resolve('uniwind/package.json')))
        } catch {
            cachedInternalBasePath = ''
        }
    }

    if (cachedInternalBasePath === '') {
        return false
    }

    const internalPathPrefix = `${cachedInternalBasePath}${sep}`
    if (originModulePath.startsWith(internalPathPrefix)) {
        return true
    }

    if (!originModulePath.includes(`${sep}node_modules${sep}uniwind${sep}`)) {
        return false
    }

    try {
        return realpathSync(originModulePath).startsWith(internalPathPrefix)
    } catch {
        return false
    }
}

const SUPPORTED_COMPONENTS = [
    'ActivityIndicator',
    'Button',
    'FlatList',
    'Image',
    'ImageBackground',
    'InputAccessoryView',
    'KeyboardAvoidingView',
    'Modal',
    'Pressable',
    'RefreshControl',
    'SafeAreaView',
    'ScrollView',
    'SectionList',
    'Switch',
    'Text',
    'TextInput',
    'TouchableHighlight',
    'TouchableNativeFeedback',
    'TouchableOpacity',
    'TouchableWithoutFeedback',
    'View',
    'VirtualizedList',
    'createOrderedCSSStyleSheet',
]

export const nativeResolver = ({
    context,
    moduleName,
    platform,
    resolver,
}: ResolverConfig) => {
    const resolution = resolver(context, moduleName, platform)

    const isInternal = isInternalOrigin(context.originModulePath)
    const nodeModulesPath = context.originModulePath.split(`${sep}node_modules${sep}`).at(-1) ?? ''
    const isFromNodeModules = nodeModulesPath !== context.originModulePath
    const isFromReactNative = nodeModulesPath.startsWith(`react-native${sep}`)
        || nodeModulesPath.startsWith(`@react-native${sep}`)
    const isReactNativeAnimated = context.originModulePath.includes(`${sep}Animated${sep}components${sep}`)

    if (
        isInternal // Is from uniwind
        || resolution.type !== 'sourceFile' // Is not a source file
        || (isFromReactNative && isFromNodeModules && !isReactNativeAnimated) // Is from react-native but not Animated
    ) {
        return resolution
    }

    if (moduleName === 'react-native') {
        return resolver(context, `uniwind/components`, platform)
    }

    if (
        resolution.filePath.includes(`${sep}react-native${sep}Libraries${sep}`)
    ) {
        const filename = basename(resolution.filePath.split(sep).at(-1) ?? '')
        const module = filename.split('.').at(0)

        if (module !== undefined && SUPPORTED_COMPONENTS.includes(module)) {
            return resolver(context, `uniwind/components/${module}`, platform)
        }
    }

    return resolution
}

export const webResolver = ({
    context,
    moduleName,
    platform,
    resolver,
}: ResolverConfig) => {
    const resolution = resolver(context, moduleName, platform)
    const resolvedNodeModulesPath = resolution.type === 'sourceFile'
        ? resolution.filePath.split(`${sep}node_modules${sep}`).at(-1) ?? ''
        : ''

    if (
        isInternalOrigin(context.originModulePath)
        || resolution.type !== 'sourceFile'
        || !resolvedNodeModulesPath.startsWith(`react-native-web${sep}`)
    ) {
        return resolution
    }

    const segments = resolution.filePath.split(sep)
    const filename = segments.at(-1) ?? ''
    const isIndex = filename.startsWith('index.')
    const module = segments.at(-2)

    // Handle createOrderedCSSStyleSheet which is in StyleSheet/dom/ subdirectory
    if (filename.startsWith('createOrderedCSSStyleSheet.')) {
        return resolver(context, `uniwind/components/createOrderedCSSStyleSheet`, platform)
    }

    const originNodeModulesPath = context.originModulePath.split(`${sep}node_modules${sep}`).at(-1) ?? ''
    const isFromReactNativeWeb = originNodeModulesPath !== context.originModulePath
        && originNodeModulesPath.startsWith(`react-native-web${sep}`)
    const isReactNativeAnimated = context.originModulePath.includes(`${sep}Animated${sep}components${sep}`)

    if (
        (isFromReactNativeWeb && !isReactNativeAnimated)
        || !isIndex
        || module === undefined
        || !SUPPORTED_COMPONENTS.includes(module)
    ) {
        return resolution
    }

    return resolver(context, `uniwind/components/${module}`, platform)
}
