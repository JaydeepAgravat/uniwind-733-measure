import { UNIWIND_PLATFORM_VARIABLES, UNIWIND_THEME_VARIABLES } from '@/common/consts'
import { isDefined } from '@/common/utils'
import type { Declaration, MediaQuery, Rule, Selector } from 'lightningcss'
import { transform } from 'lightningcss'
import type { UniwindBundlerConfig } from '../config'
import { Cascade, getSpecificity } from './cascade'
import { Color } from './color'
import { CSS } from './css'
import { Functions } from './functions'
import { MQ } from './mq'
import { RN } from './rn'
import type { ProcessMetaValues, StyleSheetTemplate, StyleTemplate } from './types'
import { Units } from './units'
import { Var } from './var'

export class ProcessorBuilder {
    stylesheets = {} as StyleSheetTemplate
    vars = {} as Record<string, any>
    scopedVars = {} as Record<string, Record<string, any>>
    CSS = new CSS(this)
    RN = new RN(this)
    Var = new Var(this)
    MQ = new MQ(this)
    Color = new Color(this)
    Units = new Units(this)
    Functions = new Functions(this)
    meta = {} as ProcessMetaValues

    private declarationConfig = this.getDeclarationConfig()
    private nextSourceOrder = 0
    private cascade = new Cascade()

    constructor(private readonly bundlerConfig: UniwindBundlerConfig) {
        this.vars['--uniwind-em'] = this.bundlerConfig.polyfills?.rem ?? 16
    }

    transform(css: string) {
        transform({
            filename: 'tailwind.css',
            code: Buffer.from(css),
            visitor: {
                StyleSheet: styleSheet =>
                    styleSheet.rules.forEach(rule => {
                        this.declarationConfig = this.getDeclarationConfig()
                        this.parseRuleRec(rule)
                    }),
            },
        })
        this.cascade.assignRanks()
    }

    private getDeclarationConfig() {
        return ({
            className: null as string | null,
            rtl: null as boolean | null,
            mediaQueries: [] as Array<Array<MediaQuery>>,
            root: false,
            theme: null as string | null,
            active: null as boolean | null,
            focus: null as boolean | null,
            disabled: null as boolean | null,
            dataAttributes: null as Record<string, string> | null,
            sourceOrder: 0,
            specificity: 0,
        })
    }

    private getStyleTemplate(): StyleTemplate {
        return {
            style: {},
            meta: {
                ...this.MQ.processMediaQueries([], this.bundlerConfig.platform),
                complexity: 0,
                importantComplexity: 0,
            },
        }
    }

    private addDeclaration(declaration: Declaration, important = false) {
        const isVar = this.declarationConfig.root || this.declarationConfig.className === null
        const mq = this.MQ.processMediaQueries(this.declarationConfig.mediaQueries, this.bundlerConfig.platform)
        const styleTemplate = isVar ? undefined : this.stylesheets[this.declarationConfig.className!]!.at(-1)!
        const style = (() => {
            if (!isVar) {
                return styleTemplate!.style
            }

            if (mq.platform !== null) {
                const platformKey = `${UNIWIND_PLATFORM_VARIABLES}${mq.platform}`
                this.scopedVars[platformKey] ??= {}

                return this.scopedVars[platformKey]
            }

            if (this.declarationConfig.theme === null) {
                return this.vars
            }

            const themeKey = `${UNIWIND_THEME_VARIABLES}${this.declarationConfig.theme}`
            this.scopedVars[themeKey] ??= {}

            return this.scopedVars[themeKey]
        })()

        if (styleTemplate) {
            const { meta } = styleTemplate

            Object.assign(meta, mq)
            this.cascade.add(meta, this.declarationConfig.specificity, this.declarationConfig.sourceOrder)
            meta.importantProperties ??= []
            meta.rtl = this.declarationConfig.rtl
            meta.theme = this.declarationConfig.theme
            meta.active = this.declarationConfig.active
            meta.focus = this.declarationConfig.focus
            meta.disabled = this.declarationConfig.disabled
            meta.dataAttributes = this.declarationConfig.dataAttributes
            this.meta.className = this.declarationConfig.className
        }

        const property = declaration.property === 'unparsed'
            ? declaration.value.propertyId.property
            : declaration.property === 'custom'
            ? declaration.value.name
            : declaration.property
        const value = declaration.property === 'unparsed' || declaration.property === 'custom'
            ? this.CSS.processValue(declaration.value.value)
            : this.CSS.processValue(declaration.value, declaration.property)

        // Reinsert repeated properties at their last declaration position before native conversion.
        delete style[property]
        style[property] = value

        if (styleTemplate && important) {
            styleTemplate.meta.importantProperties!.push(property)
        }
    }

    /**
     * Variant tokens (`:active`, `:disabled`, `:where(.dark)`, `[data-x]`, ...) found in a selector.
     * Returns null when it carries none, or `unsupported` when a compound the runtime cannot observe
     * (e.g. `[aria-disabled="true"]`) is present: the declarations must then be skipped, not applied
     * under a weaker condition. Tailwind < 4.3.3 nests variants under the class as `&:active`,
     * Tailwind >= 4.3.3 flattens them into the class selector, so both call sites share this.
     */
    private readSelectorVariants(selector: Selector) {
        let rtl = null as boolean | null
        let theme = null as string | null
        let active = null as boolean | null
        let focus = null as boolean | null
        let disabled = null as boolean | null
        let dataAttributes = null as Record<string, string> | null
        let unsupported = false

        selector.forEach(component => {
            // `&` in a nested rule and `:root` carry no condition of their own.
            if (component.type === 'nesting' || (component.type === 'pseudo-class' && component.kind === 'root')) {
                return
            }

            if (component.type === 'pseudo-class' && component.kind === 'where') {
                component.selectors.forEach(selector => {
                    selector.forEach(component => {
                        if (component.type === 'class' && this.bundlerConfig.themes.includes(component.name)) {
                            theme = component.name
                        }

                        if (component.type === 'pseudo-class' && component.kind === 'dir') {
                            rtl = component.direction === 'rtl'
                        }
                    })
                })

                return
            }

            if (component.type === 'pseudo-class' && component.kind === 'active') {
                active = true

                return
            }

            if (component.type === 'pseudo-class' && component.kind === 'focus') {
                focus = true

                return
            }

            if (component.type === 'pseudo-class' && component.kind === 'disabled') {
                disabled = true

                return
            }

            // data-x
            if (component.type === 'attribute' && component.operation === null && component.name.startsWith('data-')) {
                dataAttributes ??= {}
                dataAttributes[component.name] = `"true"`

                return
            }

            // data-x=
            if (component.type === 'attribute' && component.operation?.operator === 'equal' && component.name.startsWith('data-')) {
                dataAttributes ??= {}
                dataAttributes[component.name] = JSON.stringify(component.operation.value)

                return
            }

            unsupported = true
        })

        if (unsupported) {
            return 'unsupported'
        }

        if (![rtl, theme, active, focus, disabled, dataAttributes].some(isDefined)) {
            return null
        }

        return { rtl, theme, active, focus, disabled, dataAttributes }
    }

    private withSelectorVariants(
        variants: Exclude<ReturnType<ProcessorBuilder['readSelectorVariants']>, null | 'unsupported'>,
        parse: () => void,
    ) {
        this.declarationConfig.rtl ??= variants.rtl
        this.declarationConfig.theme ??= variants.theme
        this.declarationConfig.active ??= variants.active
        this.declarationConfig.focus ??= variants.focus
        this.declarationConfig.disabled ??= variants.disabled
        this.declarationConfig.dataAttributes ??= variants.dataAttributes

        parse()

        this.declarationConfig.rtl = null
        this.declarationConfig.theme = null
        this.declarationConfig.active = null
        this.declarationConfig.focus = null
        this.declarationConfig.disabled = null
        this.declarationConfig.dataAttributes = null
    }

    private parseRuleRec(rule: Rule<Declaration, MediaQuery>, parentSpecificity = 0) {
        this.declarationConfig.sourceOrder = this.nextSourceOrder++
        this.declarationConfig.specificity = parentSpecificity

        if (this.declarationConfig.className !== null) {
            const lastStyle = this.stylesheets[this.declarationConfig.className]?.at(-1)

            if (lastStyle !== undefined && Object.keys(lastStyle.style).length > 0) {
                this.stylesheets[this.declarationConfig.className]?.push(this.getStyleTemplate())
            }
        }

        if (rule.type === 'style') {
            const previousRoot = this.declarationConfig.root
            const nestedSpecificity = Math.max(...rule.value.selectors.map(selector => getSpecificity(selector, parentSpecificity)))

            rule.value.selectors.forEach(selector => {
                const specificity = getSpecificity(selector, parentSpecificity)
                this.declarationConfig.specificity = specificity

                const parseNestedRule = (nestedRule: Rule<Declaration, MediaQuery>) => {
                    const outerConfig = this.declarationConfig

                    this.declarationConfig = { ...outerConfig }
                    this.parseRuleRec(nestedRule, nestedRule.type === 'nested-declarations' ? specificity : nestedSpecificity)
                    this.declarationConfig = outerConfig
                }
                const parseStyleRule = () => {
                    rule.value.declarations?.declarations?.forEach(declaration => this.addDeclaration(declaration))
                    rule.value.declarations?.importantDeclarations?.forEach(declaration => this.addDeclaration(declaration, true))
                    rule.value.rules?.forEach(parseNestedRule)
                }
                const [maybeClassNameSelector] = selector
                const newClassName = maybeClassNameSelector?.type === 'class' ? maybeClassNameSelector.name : undefined
                this.declarationConfig.root = newClassName === undefined ? previousRoot : false

                if (newClassName !== undefined) {
                    this.declarationConfig.className = newClassName
                    this.stylesheets[newClassName] ??= []
                    this.stylesheets[newClassName].push(this.getStyleTemplate())

                    // Tailwind >= 4.3.3 emits `.active\:x:active {}` instead of nesting
                    // `&:active` under the class, so the variant tokens follow the class token.
                    const variants = this.readSelectorVariants(selector.slice(1))

                    if (variants === 'unsupported') {
                        return
                    }

                    if (variants === null) {
                        parseStyleRule()
                    } else {
                        this.withSelectorVariants(variants, parseStyleRule)
                    }

                    return
                }

                const variants = this.readSelectorVariants(selector)

                if (variants === 'unsupported') {
                    return
                }

                if (variants !== null) {
                    this.withSelectorVariants(variants, parseStyleRule)

                    return
                }

                selector.forEach(selectorToken => {
                    if (selectorToken.type === 'pseudo-class' && selectorToken.kind === 'root') {
                        this.declarationConfig.root = true

                        parseStyleRule()
                    }
                })
            })
            this.declarationConfig.root = previousRoot

            return
        }

        // Skip web: variant
        if (rule.type === 'supports' && rule.value.condition.value !== 'div > div') {
            rule.value.rules.forEach(rule => this.parseRuleRec(rule, parentSpecificity))

            return
        }

        if (rule.type === 'media') {
            const { mediaQueries } = rule.value.query
            // The block's media queries have to outlive the reset between its
            // sibling rules: resetting only after each parse left every rule past
            // the first without the block's queries, shipping `ios:`/`android:`
            // variants and later utilities of a width breakpoint unguarded to
            // every platform/breakpoint. Reset to the outer config instead of a
            // fresh one so media nested inside a class rule keeps writing into
            // that class.
            const outerConfig = this.declarationConfig
            const blockMediaQueries = [...outerConfig.mediaQueries, mediaQueries]

            rule.value.rules.forEach(rule => {
                this.declarationConfig = { ...outerConfig, mediaQueries: blockMediaQueries }
                this.parseRuleRec(rule, parentSpecificity)
            })

            this.declarationConfig = outerConfig
            return
        }

        if (rule.type === 'layer-statement') {
            rule.value.names.forEach(name => this.cascade.declareLayer(name))

            return
        }

        if (rule.type === 'layer-block') {
            this.cascade.withLayer(rule.value.name ?? null, () => {
                rule.value.rules.forEach(rule => this.parseRuleRec(rule, parentSpecificity))
            })

            return
        }

        if (rule.type === 'nested-declarations') {
            rule.value.declarations.declarations?.forEach(declaration => this.addDeclaration(declaration))
            rule.value.declarations.importantDeclarations?.forEach(declaration => this.addDeclaration(declaration, true))

            return
        }

        if (rule.type === 'property' && rule.value.initialValue) {
            this.vars[rule.value.name] = this.CSS.processValue(rule.value.initialValue)
        }
    }
}
