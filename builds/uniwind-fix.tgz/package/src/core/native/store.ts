import { Dimensions, Platform } from 'react-native'
import { Orientation, Platform as UniwindPlatform, StyleDependency, UNIWIND_PLATFORM_VARIABLES, UNIWIND_THEME_VARIABLES } from '../../common/consts'
import { UniwindListener } from '../listener'
import type { ComponentState, GenerateStyleSheetsCallback, RNStyle, Style, StyleSheets, ThemeName, UniwindContextType, Var, Vars } from '../types'
import { getScopedVars } from './native-utils'
import {
    parseBoxShadow,
    parseFontVariant,
    parseFontVariationSettings,
    parseTextShadowMutation,
    parseTransformsMutation,
    resolveGradient,
} from './parsers'
import { UniwindRuntime } from './runtime'

type StylesResult = {
    styles: RNStyle
    dependencies: Array<StyleDependency>
    dependencySum: number
}

const emptyState: StylesResult = { styles: {}, dependencies: [], dependencySum: 0 }

const splitClassNames = (classNames: string) =>
    classNames.includes('\n')
        ? classNames.split(/\s+/).filter(Boolean)
        : classNames.split(' ')

// Reduces a data attribute value to what the generated match functions can tell apart:
// true and "true" match the same rules, so do false and "false", other strings only match
// themselves, and any other value never matches.
const toDataAttributeCacheValue = (value: unknown) => {
    if (value === true || value === 'true') {
        return true
    }

    if (value === false || value === 'false') {
        return false
    }

    return typeof value === 'string' ? value : null
}

class UniwindStoreBuilder {
    runtime = UniwindRuntime
    vars = {} as Record<ThemeName, Vars>
    private stylesheet = {} as StyleSheets
    private cache = {} as Record<ThemeName, Map<string, StylesResult>>
    // The stylesheet doesn't change between reinits, so the data attributes a class string
    // depends on are worked out once per class string
    private dataAttributeNamesCache = new Map<string, Array<string>>()

    getStyles(
        className: string | undefined,
        componentProps: Record<string, any> | undefined,
        state: ComponentState | undefined,
        uniwindContext: UniwindContextType,
    ): StylesResult {
        if (className === undefined || className === '') {
            return emptyState
        }

        const isScopedTheme = uniwindContext.scopedTheme !== null
        const cacheKey = `${className}${state?.isDisabled ?? false}${state?.isFocused ?? false}${state?.isPressed ?? false}${isScopedTheme}${
            uniwindContext.rtl ?? ''
        }${uniwindContext.variables?.__uniwindVariablesCacheKey ?? ''}${this.getDataAttributesCacheKey(className, componentProps)}`
        const cache = this.cache[uniwindContext.scopedTheme ?? this.runtime.currentThemeName]

        if (!cache) {
            return emptyState
        }

        if (cache.has(cacheKey)) {
            return cache.get(cacheKey)!
        }

        const result = this.resolveStyles(className, componentProps, state, uniwindContext)

        cache.set(cacheKey, result)
        UniwindListener.subscribe(
            () => cache.delete(cacheKey),
            result.dependencies,
            { once: true },
        )

        return result
    }

    private getDataAttributesCacheKey(className: string, componentProps: Record<string, any> | undefined) {
        let dataAttributeNames = this.dataAttributeNamesCache.get(className)

        if (dataAttributeNames === undefined) {
            const names = new Set<string>()

            for (const token of splitClassNames(className)) {
                if (!(token in this.stylesheet)) {
                    continue
                }

                for (const style of this.stylesheet[token] as Array<Style>) {
                    style.dataAttributeNames?.forEach(name => names.add(name))
                }
            }

            dataAttributeNames = Array.from(names)
            this.dataAttributeNamesCache.set(className, dataAttributeNames)
        }

        if (dataAttributeNames.length === 0) {
            return ''
        }

        return JSON.stringify(dataAttributeNames.map(name => toDataAttributeCacheValue(componentProps?.[name])))
    }

    reinit = (generateStyleSheetCallback: GenerateStyleSheetsCallback, themes: Array<string>) => {
        const config = generateStyleSheetCallback(this.runtime)
        const { scopedVars, stylesheet, vars } = config
        const platform = this.getCurrentPlatform()
        const commonPlatform = platform.includes('tv') ? UniwindPlatform.TV : UniwindPlatform.Native
        const commonPlatformVars = scopedVars[`${UNIWIND_PLATFORM_VARIABLES}${commonPlatform}`]
        const platformVars = scopedVars[`${UNIWIND_PLATFORM_VARIABLES}${platform}`]

        if (commonPlatformVars) {
            Object.assign(vars, commonPlatformVars)
        }

        if (platformVars) {
            Object.assign(vars, platformVars)
        }

        this.stylesheet = stylesheet
        this.vars = Object.fromEntries(themes.map(theme => {
            const clonedVars = Object.create(vars) as Vars
            const themeVars = scopedVars[`${UNIWIND_THEME_VARIABLES}${theme}`]

            if (themeVars) {
                Object.assign(clonedVars, themeVars)
            }

            return [theme, clonedVars]
        }))
        this.cache = Object.fromEntries(themes.map(theme => [theme, new Map()]))
        this.dataAttributeNamesCache = new Map()

        if (__DEV__) {
            UniwindListener.notifyAll()
        }
    }

    private resolveStyles(
        classNames: string,
        componentProps: Record<string, any> | undefined,
        state: ComponentState | undefined,
        uniwindContext: UniwindContextType,
    ) {
        const resultGetters = {} as Record<string, Var>
        const theme = uniwindContext.scopedTheme ?? this.runtime.currentThemeName
        // At this point we're sure that theme is correct
        const themeVars = this.vars[theme]!
        // Overlay scoped variables onto a prototype-chained clone so unset vars fall through to the theme
        let vars = uniwindContext.variables === null
            ? themeVars
            : Object.assign(
                Object.create(themeVars) as Vars,
                getScopedVars(uniwindContext.variables),
            )
        const originalVars = vars
        const dependencies = new Set<StyleDependency>()
        let dependencySum = 0
        const bestRanks = new Map<string, number>()
        const isScopedTheme = uniwindContext.scopedTheme !== null
        const classNameTokens = splitClassNames(classNames)

        for (const className of classNameTokens) {
            if (!(className in this.stylesheet)) {
                continue
            }

            for (const style of this.stylesheet[className] as Array<Style>) {
                if (style.dependencies) {
                    style.dependencies.forEach(dep => {
                        if (dep === StyleDependency.Theme && isScopedTheme) {
                            return
                        }

                        dependencies.add(dep)
                        dependencySum |= 1 << dep
                    })
                }

                if (!style.matches(this.runtime, uniwindContext, componentProps, state, vars)) {
                    continue
                }

                for (const [property, valueGetter] of style.entries) {
                    const rank = style.importantProperties.includes(property) ? style.importantComplexity : style.complexity
                    const previousRank = bestRanks.get(property)

                    if (previousRank !== undefined && previousRank > rank) {
                        continue
                    }

                    if (property[0] === '-') {
                        // Clone vars object if we are adding inline variables
                        if (vars === originalVars) {
                            vars = Object.create(originalVars)
                        }

                        vars[property] = valueGetter
                    } else {
                        resultGetters[property] = valueGetter
                    }

                    bestRanks.set(property, rank)
                }
            }
        }

        const result = Object.fromEntries(
            Object.entries(resultGetters).map(([property, valueGetter]) => [property, valueGetter(vars)]),
        ) as Record<string, any>

        if (result.lineHeight !== undefined && result.lineHeight < 6) {
            result.lineHeight *= result.fontSize
        }

        if (result.boxShadow !== undefined) {
            result.boxShadow = parseBoxShadow(result.boxShadow)
        }

        if (result.visibility === 'hidden') {
            result.display = 'none'
        }

        if (
            result.borderStyle !== undefined && result.borderColor === undefined
        ) {
            result.borderColor = '#000000'
        }

        if (
            result.outlineStyle !== undefined && result.outlineColor === undefined
        ) {
            result.outlineColor = '#000000'
        }

        if (result.fontVariant !== undefined) {
            result.fontVariant = parseFontVariant(result.fontVariant)
        }

        if (typeof result.fontVariationSettings === 'string') {
            result.fontVariationSettings = parseFontVariationSettings(result.fontVariationSettings)
        }

        parseTransformsMutation(result)

        if (result.experimental_backgroundImage !== undefined) {
            result.experimental_backgroundImage = resolveGradient(result.experimental_backgroundImage)
        }

        if (result.textShadow !== undefined) {
            parseTextShadowMutation(result)
        }

        return {
            styles: result,
            dependencies: Array.from(dependencies),
            dependencySum,
        }
    }

    private getCurrentPlatform() {
        const platform = Platform.OS

        if (platform === 'android') {
            return Platform.isTV ? UniwindPlatform.AndroidTV : UniwindPlatform.Android
        }

        if (platform === 'ios') {
            return Platform.isTV ? UniwindPlatform.AppleTV : UniwindPlatform.iOS
        }

        return platform
    }
}

export const UniwindStore = new UniwindStoreBuilder()

Dimensions.addEventListener('change', ({ window }: { window: ReturnType<typeof Dimensions.get> }) => {
    const newOrientation = window.width > window.height ? Orientation.Landscape : Orientation.Portrait
    const orientationChanged = UniwindStore.runtime.orientation !== newOrientation

    UniwindStore.runtime.screen = {
        width: window.width,
        height: window.height,
    }
    UniwindStore.runtime.orientation = newOrientation
    UniwindListener.notify([
        ...orientationChanged ? [StyleDependency.Orientation] : [],
        StyleDependency.Dimensions,
    ])
})
