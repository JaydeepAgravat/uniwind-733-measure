import { StyleDependency } from '../../common/consts'
import { UniwindListener } from '../listener'

const MAX_CLASS_NAME_CACHE_SIZE = 500

class CSSListenerBuilder {
    activeRules = new Set<CSSStyleRule>()
    private classNameRules = new Map<string, Array<CSSStyleRule>>()
    private classNameMediaQueryListeners = new Map<string, MediaQueryList>()
    private listeners = new Map<MediaQueryList, Set<VoidFunction>>()
    private registeredRulesMediaQueries = new Map<string, MediaQueryList>()
    private processedStyleSheets = new WeakSet<CSSStyleSheet>()
    private pendingInitialization: number | undefined = undefined

    constructor() {
        if (typeof document === 'undefined') {
            return
        }

        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                if (mutation.type === 'attributes') {
                    const el = mutation.target as HTMLLinkElement | HTMLStyleElement

                    if (!('sheet' in el)) {
                        continue
                    }

                    const sheet = el.sheet

                    if (sheet) {
                        this.processedStyleSheets.delete(sheet)
                    }

                    this.scheduleInitialization()
                }

                if (mutation.type === 'childList') {
                    this.scheduleInitialization()
                }
            }
        })

        this.initialize()
        observer.observe(document.head, {
            childList: true,
            subtree: false,
            attributes: true,
            attributeFilter: ['disabled', 'media', 'title', 'href', 'rel'],
        })
    }

    getRulesForClassName(className: string) {
        const cached = this.classNameRules.get(className)

        if (cached) {
            this.classNameRules.delete(className)
            this.classNameRules.set(className, cached)

            return cached
        }

        const selectors = className.split(/\s+/).filter(Boolean).map(cls => `.${CSS.escape(cls)}`)
        const rules = Array.from(this.activeRules).filter(rule => selectors.some(cls => rule.selectorText.includes(cls)))

        if (this.classNameRules.size >= MAX_CLASS_NAME_CACHE_SIZE) {
            this.classNameRules.delete(this.classNameRules.keys().next().value!)
        }

        this.classNameRules.set(className, rules)

        return rules
    }

    getSnapshot(classNames: string) {
        const mediaQueries = new Set(
            classNames
                .split(' ')
                .map(className => this.classNameMediaQueryListeners.get(className))
                .filter(mediaQuery => mediaQuery !== undefined),
        )
        const themeSnapshot = UniwindListener.getSnapshot([StyleDependency.Theme, StyleDependency.Variables])

        return `${themeSnapshot}:${Array.from(mediaQueries).map(mediaQuery => Number(mediaQuery.matches)).join('')}`
    }

    subscribeToClassName(classNames: string, listener: VoidFunction) {
        const disposables = [] as Array<VoidFunction>

        classNames.split(' ').forEach(className => {
            const mediaQuery = this.classNameMediaQueryListeners.get(className)

            if (!mediaQuery) {
                return () => {}
            }

            const listeners = this.listeners.get(mediaQuery)

            listeners?.add(listener)
            disposables.push(() => listeners?.delete(listener))
        })

        const disposeThemeListener = UniwindListener.subscribe(listener, [StyleDependency.Theme, StyleDependency.Variables])

        return () => {
            disposables.forEach(disposable => disposable())
            disposeThemeListener()
        }
    }

    private scheduleInitialization() {
        this.cancelPendingInitialization()

        if (typeof requestIdleCallback !== 'undefined') {
            this.pendingInitialization = requestIdleCallback(() => {
                this.initialize()
            }, { timeout: 50 })

            return
        }

        this.pendingInitialization = setTimeout(() => {
            this.initialize()
        }, 50) as unknown as number
    }

    private cancelPendingInitialization() {
        if (this.pendingInitialization !== undefined) {
            if (typeof cancelIdleCallback !== 'undefined') {
                cancelIdleCallback(this.pendingInitialization)
            } else {
                clearTimeout(this.pendingInitialization)
            }

            this.pendingInitialization = undefined
        }
    }

    private pruneStaleRules() {
        const activeSheets = new Set(Array.from(document.styleSheets))

        for (const rule of this.activeRules) {
            if (!rule.parentStyleSheet || !activeSheets.has(rule.parentStyleSheet)) {
                this.activeRules.delete(rule)
            }
        }
    }

    private initialize() {
        this.classNameRules.clear()
        this.pendingInitialization = undefined

        if (typeof document === 'undefined') {
            return
        }

        this.pruneStaleRules()
        let added = false

        for (const sheet of Array.from(document.styleSheets)) {
            // Skip already processed stylesheets
            if (this.processedStyleSheets.has(sheet)) {
                continue
            }

            let rules: CSSRuleList

            try {
                // May throw for cross-origin stylesheets
                rules = sheet.cssRules
            } catch {
                continue
            }

            // oxlint-disable-next-line @typescript-eslint/strict-boolean-expressions
            if (!rules) {
                continue
            }

            // Mark as processed after successful cssRules access
            this.processedStyleSheets.add(sheet)

            this.addMediaQueriesDeep(rules)
            added = true
        }

        if (added) {
            UniwindListener.notify([StyleDependency.Variables])
        }
    }

    private isStyleRule(rule: CSSRule): rule is CSSStyleRule {
        return rule.constructor.name === 'CSSStyleRule'
    }

    private isMediaRule(rule: CSSRule): rule is CSSMediaRule {
        return rule.constructor.name === 'CSSMediaRule'
    }

    private isSupportsRule(rule: CSSRule): rule is CSSSupportsRule {
        return rule.constructor.name === 'CSSSupportsRule'
    }

    private collectParentMediaQueries(rule: CSSRule, acc = [] as Array<CSSMediaRule>): Array<CSSMediaRule> {
        const { parentRule } = rule

        if (!parentRule) {
            return []
        }

        if (this.isMediaRule(parentRule)) {
            acc.push(parentRule)
        }

        const result = this.collectParentMediaQueries(parentRule, acc)

        acc.push(...result)

        return Array.from(new Set(acc))
    }

    private addMediaQueriesDeep(rules: CSSRuleList) {
        for (const rule of Array.from(rules)) {
            if (this.isStyleRule(rule)) {
                const mediaQueries = this.collectParentMediaQueries(rule)

                this.activeRules.add(rule)

                if (mediaQueries.length > 0) {
                    this.addMediaQuery(mediaQueries, rule)
                }

                continue
            }

            if (this.isSupportsRule(rule)) {
                if (!CSS.supports(rule.conditionText)) {
                    continue
                }

                this.addMediaQueriesDeep(rule.cssRules)

                continue
            }

            if ('cssRules' in rule && rule.cssRules instanceof CSSRuleList) {
                this.addMediaQueriesDeep(rule.cssRules)

                continue
            }
        }
    }

    private addMediaQuery(mediaQueries: Array<CSSMediaRule>, rule: CSSStyleRule) {
        const className = rule.selectorText
        const rules = mediaQueries.map(mediaQuery => mediaQuery.conditionText).sort().join(' and ')
        const parsedClassName = className.replace('.', '').replace('\\', '')
        const cachedMediaQueryList = this.registeredRulesMediaQueries.get(rules)

        if (cachedMediaQueryList) {
            this.classNameMediaQueryListeners.set(parsedClassName, cachedMediaQueryList)
            this.toggleRule(cachedMediaQueryList, rule)

            cachedMediaQueryList.addEventListener('change', () => {
                this.toggleRule(cachedMediaQueryList, rule)
            })

            return
        }

        const mediaQueryList = window.matchMedia(rules)

        this.toggleRule(mediaQueryList, rule)
        this.registeredRulesMediaQueries.set(rules, mediaQueryList)
        this.listeners.set(mediaQueryList, new Set())
        this.classNameMediaQueryListeners.set(parsedClassName, mediaQueryList)

        mediaQueryList.addEventListener('change', () => {
            this.listeners.get(mediaQueryList)!.forEach(listener => {
                listener()
            })
            this.toggleRule(mediaQueryList, rule)
        })
    }

    private isRuleLive(rule: CSSStyleRule) {
        const sheet = rule.parentStyleSheet
        return sheet !== null && Array.from(document.styleSheets).includes(sheet)
    }

    private toggleRule(mqList: MediaQueryList, rule: CSSStyleRule) {
        this.classNameRules.clear()
        if (mqList.matches && this.isRuleLive(rule)) {
            this.activeRules.add(rule)
        } else {
            this.activeRules.delete(rule)
        }
    }
}

export const CSSListener = new CSSListenerBuilder()
